# ofxVideoSync

Addon for synching video playback of multiple videos, both on a machine and across a local network.

Currently tested and works on Raspberry Pi and Linux.

You need to connect devices using a LAN cable, WIFI isn't reliable enough to sync.

